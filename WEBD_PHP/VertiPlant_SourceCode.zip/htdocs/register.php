<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VertiPlant | Register</title>
    <link rel="stylesheet" href="styling.css">
</head>
<body>
<div class="page">
    <?php require 'navigational.php';?>
    <main class="login-layout">
        <section class="hero">
            <div class="brand"><span class="brand-mark">♧</span><span>VertiPlant</span></div>
            <div class="hero-copy">
                <h1>Practical and reliable way to manage vertical farming.</h1>
                <p>Help vertical farm owners in managing crops and harvests in a more organized way.</p>
            </div>
        </section>
        <section class="form-side">
            <form class="login-card" action="" method="post">
                <h2>Welcome</h2>
                <p class="subtitle">Create a free account with us today!</p>
                <label for="fName">First Name:</label>
                <input id="fName" name="fName" type="text" required>
                <label for="lName">Last Name:</label>
                <input id="lName" name="lName" type="text" required>
                <label for="email">Email:</label>
                <input id="email" name="email" type="email" required>
                <label for="password">Password:</label>
                <input id="password" name="password" type="password" required>
                <button type="submit">Register</button>
            </form>
        </section>
    </main>
    <?php require 'footer.php';?>
</div>
</body>
</html>